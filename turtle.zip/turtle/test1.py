import turtle
 
def drawMulticolorSquare(t, sz):
    for colors in ['red','purple','hotpink','blue']:
        t.color(colors)
        t.forward(sz)
        t.left(90)
 
wn = turtle.Screen()             # Set up the window and its attributes
wn.bgcolor("black")
 
tess = turtle.Turtle()           # create tess and set some attributes
tess.pensize(3)
 
size = 100    
tess.goto (-320, 0)                   # size of the smallest square
for colored_squares in range(5):
    
    drawMulticolorSquare(tess, size) 
    
    tess.penup()
    tess.forward(130)
    tess.pendown()
            
 
wn.exitonclick()
