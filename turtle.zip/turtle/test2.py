import turtle
 
def drawMulticolorSquare(t, sz):
    for colors in ['red','purple','hotpink','blue']:
        t.color(colors)
        t.forward(sz)
        t.left(90)
 
wn = turtle.Screen()             # Set up the window and its attributes
wn.bgcolor("black")
 
tess = turtle.Turtle()           # create tess and set some attributes
tess.pensize(3)

tess.goto (-15, -15)
size = 20                        # size of the smallest square
for colored_squares in range(100):
    drawMulticolorSquare(tess, size)
    size = size + 20 
    tess.penup()
    tess.backward(10)
    tess.right(90)
    tess.forward(10)
    tess.left(90)
    tess.pendown()            # move tess along a little
                   # and give her some extra turn
 
wn.exitonclick()