import turtle
 
def drawPoly(t, sz):
    for colors in ['red','purple','hotpink','blue','red','purple','hotpink','blue']:
        t.color(colors)
        t.forward(sz)
        t.left(45)
 
wn = turtle.Screen()            

 
tess = turtle.Turtle()          
tess.pensize(3)
 
size = 150   
tess.goto (-100, -150)                   
for colored_squares in range(1):
    
    drawPoly(tess, size) 
    
    tess.penup()
    tess.forward(130)
    tess.pendown()
            
 
wn.exitonclick()