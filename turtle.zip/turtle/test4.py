import turtle
 
def drawMulticolorSquare(t, sz):
    for colors in ['blue','purple','hotpink','blue']:
        t.color(colors)
        t.forward(sz)
        t.left(90)
 
wn = turtle.Screen()             # Set up the window and its attributes
wn.bgcolor("black")
 
tess = turtle.Turtle()           # create tess and set some attributes
tess.pensize(3)
 
size = 200                        # size of the smallest square
for colored_squares in range(24):
    drawMulticolorSquare(tess, size) 
    tess.right(15)
             # move tess along a little
                   # and give her some extra turn
 
wn.exitonclick()